import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import HomePage from './pages/HomePage';
import NotesPage from './pages/NotesPage';
import PhysicsSimulator from './pages/PhysicsSimulator';
import MathCalculator from './pages/MathCalculator';
import FlashcardsPage from './pages/FlashcardsPage';
import CommunityPage from './pages/CommunityPage';
import Navbar from './components/Navbar';

function App() {
  return (
    <Router>
      <div className="min-h-screen bg-gradient-to-br from-indigo-100 via-purple-100 to-pink-100">
        <Navbar />
        <div className="container mx-auto px-4 py-8">
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/notes" element={<NotesPage />} />
            <Route path="/physics" element={<PhysicsSimulator />} />
            <Route path="/math" element={<MathCalculator />} />
            <Route path="/flashcards" element={<FlashcardsPage />} />
            <Route path="/community" element={<CommunityPage />} />
          </Routes>
        </div>
      </div>
    </Router>
  );
}

export default App;