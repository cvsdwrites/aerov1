import { create } from 'zustand';
import { persist } from 'zustand/middleware';

export interface Post {
  id: string;
  title: string;
  content: string;
  author: string;
  tags: string[];
  createdAt: string;
  updatedAt: string;
  likes: number;
  comments: Comment[];
}

export interface Comment {
  id: string;
  content: string;
  author: string;
  createdAt: string;
  likes: number;
}

interface CommunityState {
  posts: Post[];
  currentUser: string;
  addPost: (post: Omit<Post, 'id' | 'createdAt' | 'updatedAt' | 'likes' | 'comments'>) => void;
  updatePost: (id: string, updates: Partial<Omit<Post, 'id' | 'createdAt' | 'comments'>>) => void;
  deletePost: (id: string) => void;
  likePost: (id: string) => void;
  addComment: (postId: string, comment: Omit<Comment, 'id' | 'createdAt' | 'likes'>) => void;
  deleteComment: (postId: string, commentId: string) => void;
  likeComment: (postId: string, commentId: string) => void;
  setCurrentUser: (username: string) => void;
}

export const useCommunityStore = create<CommunityState>()(
  persist(
    (set) => ({
      posts: [],
      currentUser: 'Anonymous User',
      
      addPost: (postData) => 
        set((state) => {
          const newPost = {
            id: Date.now().toString(),
            ...postData,
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString(),
            likes: 0,
            comments: []
          };
          return { posts: [newPost, ...state.posts] };
        }),
      
      updatePost: (id, updates) =>
        set((state) => ({
          posts: state.posts.map((post) =>
            post.id === id 
              ? { 
                  ...post, 
                  ...updates, 
                  updatedAt: new Date().toISOString() 
                } 
              : post
          ),
        })),
      
      deletePost: (id) =>
        set((state) => ({
          posts: state.posts.filter((post) => post.id !== id),
        })),
      
      likePost: (id) =>
        set((state) => ({
          posts: state.posts.map((post) =>
            post.id === id ? { ...post, likes: post.likes + 1 } : post
          ),
        })),
      
      addComment: (postId, commentData) =>
        set((state) => {
          const newComment = {
            id: Date.now().toString(),
            ...commentData,
            createdAt: new Date().toISOString(),
            likes: 0
          };
          
          return {
            posts: state.posts.map((post) =>
              post.id === postId
                ? { 
                    ...post, 
                    comments: [...post.comments, newComment],
                    updatedAt: new Date().toISOString()
                  }
                : post
            ),
          };
        }),
      
      deleteComment: (postId, commentId) =>
        set((state) => ({
          posts: state.posts.map((post) =>
            post.id === postId
              ? { 
                  ...post, 
                  comments: post.comments.filter(
                    (comment) => comment.id !== commentId
                  ),
                  updatedAt: new Date().toISOString()
                }
              : post
          ),
        })),
      
      likeComment: (postId, commentId) =>
        set((state) => ({
          posts: state.posts.map((post) =>
            post.id === postId
              ? {
                  ...post,
                  comments: post.comments.map((comment) =>
                    comment.id === commentId
                      ? { ...comment, likes: comment.likes + 1 }
                      : comment
                  ),
                }
              : post
          ),
        })),
      
      setCurrentUser: (username) =>
        set(() => ({
          currentUser: username,
        })),
    }),
    {
      name: 'community-storage',
    }
  )
);