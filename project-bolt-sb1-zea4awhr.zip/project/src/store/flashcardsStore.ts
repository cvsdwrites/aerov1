import { create } from 'zustand';
import { persist } from 'zustand/middleware';

export interface Flashcard {
  id: string;
  question: string;
  answer: string;
  deckId: string;
  lastReviewed: string | null;
  difficulty: 'easy' | 'medium' | 'hard';
}

export interface Deck {
  id: string;
  name: string;
  description: string;
  createdAt: string;
  cardCount: number;
}

interface FlashcardsState {
  decks: Deck[];
  cards: Flashcard[];
  addDeck: (deck: Omit<Deck, 'cardCount'>) => void;
  updateDeck: (id: string, updates: Partial<Omit<Deck, 'id' | 'cardCount'>>) => void;
  deleteDeck: (id: string) => void;
  addCard: (card: Omit<Flashcard, 'id' | 'lastReviewed' | 'difficulty'>) => void;
  updateCard: (id: string, updates: Partial<Omit<Flashcard, 'id'>>) => void;
  deleteCard: (id: string) => void;
  updateCardReview: (id: string, difficulty: 'easy' | 'medium' | 'hard') => void;
}

export const useFlashcardsStore = create<FlashcardsState>()(
  persist(
    (set) => ({
      decks: [],
      cards: [],
      
      addDeck: (deckData) => 
        set((state) => {
          const newDeck = {
            ...deckData,
            cardCount: 0
          };
          return { decks: [...state.decks, newDeck] };
        }),
      
      updateDeck: (id, updates) =>
        set((state) => ({
          decks: state.decks.map((deck) =>
            deck.id === id ? { ...deck, ...updates } : deck
          ),
        })),
      
      deleteDeck: (id) =>
        set((state) => ({
          decks: state.decks.filter((deck) => deck.id !== id),
          cards: state.cards.filter((card) => card.deckId !== id),
        })),
      
      addCard: (cardData) => 
        set((state) => {
          const newCard = {
            id: Date.now().toString(),
            ...cardData,
            lastReviewed: null,
            difficulty: 'medium' as const,
          };
          
          // Update the card count for the deck
          const updatedDecks = state.decks.map(deck => 
            deck.id === cardData.deckId 
              ? { ...deck, cardCount: deck.cardCount + 1 }
              : deck
          );
          
          return { 
            cards: [...state.cards, newCard],
            decks: updatedDecks
          };
        }),
      
      updateCard: (id, updates) =>
        set((state) => ({
          cards: state.cards.map((card) =>
            card.id === id ? { ...card, ...updates } : card
          ),
        })),
      
      deleteCard: (id) =>
        set((state) => {
          const cardToDelete = state.cards.find(card => card.id === id);
          if (!cardToDelete) return state;
          
          // Update the card count for the deck
          const updatedDecks = state.decks.map(deck => 
            deck.id === cardToDelete.deckId 
              ? { ...deck, cardCount: Math.max(0, deck.cardCount - 1) }
              : deck
          );
          
          return {
            cards: state.cards.filter((card) => card.id !== id),
            decks: updatedDecks
          };
        }),
      
      updateCardReview: (id, difficulty) =>
        set((state) => ({
          cards: state.cards.map((card) =>
            card.id === id 
              ? { 
                  ...card, 
                  lastReviewed: new Date().toISOString(),
                  difficulty 
                } 
              : card
          ),
        })),
    }),
    {
      name: 'flashcards-storage',
    }
  )
);