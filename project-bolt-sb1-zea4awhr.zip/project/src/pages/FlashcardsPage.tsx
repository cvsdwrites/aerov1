import React, { useState } from 'react';
import { useFlashcardsStore } from '../store/flashcardsStore';
import { BookOpen, Plus, Edit, Trash2, ChevronRight, ChevronLeft, Check, X, RotateCcw } from 'lucide-react';

const FlashcardsPage = () => {
  const { decks, cards, addDeck, updateDeck, deleteDeck, addCard, updateCard, deleteCard, updateCardReview } = useFlashcardsStore();
  
  const [activeDeck, setActiveDeck] = useState<string | null>(null);
  const [isStudying, setIsStudying] = useState(false);
  const [currentCardIndex, setCurrentCardIndex] = useState(0);
  const [showAnswer, setShowAnswer] = useState(false);
  
  const [isCreatingDeck, setIsCreatingDeck] = useState(false);
  const [newDeckName, setNewDeckName] = useState('');
  const [newDeckDescription, setNewDeckDescription] = useState('');
  
  const [isCreatingCard, setIsCreatingCard] = useState(false);
  const [newCardQuestion, setNewCardQuestion] = useState('');
  const [newCardAnswer, setNewCardAnswer] = useState('');
  
  const [editingDeck, setEditingDeck] = useState<string | null>(null);
  const [editDeckName, setEditDeckName] = useState('');
  const [editDeckDescription, setEditDeckDescription] = useState('');
  
  const [editingCard, setEditingCard] = useState<string | null>(null);
  const [editCardQuestion, setEditCardQuestion] = useState('');
  const [editCardAnswer, setEditCardAnswer] = useState('');
  
  const filteredCards = activeDeck ? cards.filter(card => card.deckId === activeDeck) : [];
  const studyCards = [...filteredCards].sort(() => Math.random() - 0.5);
  
  const handleCreateDeck = () => {
    if (newDeckName.trim()) {
      addDeck({
        id: Date.now().toString(),
        name: newDeckName,
        description: newDeckDescription,
        createdAt: new Date().toISOString(),
      });
      setNewDeckName('');
      setNewDeckDescription('');
      setIsCreatingDeck(false);
    }
  };
  
  const handleUpdateDeck = () => {
    if (editingDeck && editDeckName.trim()) {
      updateDeck(editingDeck, {
        name: editDeckName,
        description: editDeckDescription,
      });
      setEditingDeck(null);
    }
  };
  
  const handleCreateCard = () => {
    if (activeDeck && newCardQuestion.trim() && newCardAnswer.trim()) {
      addCard({
        question: newCardQuestion,
        answer: newCardAnswer,
        deckId: activeDeck,
      });
      setNewCardQuestion('');
      setNewCardAnswer('');
      setIsCreatingCard(false);
    }
  };
  
  const handleUpdateCard = () => {
    if (editingCard && editCardQuestion.trim() && editCardAnswer.trim()) {
      updateCard(editingCard, {
        question: editCardQuestion,
        answer: editCardAnswer,
      });
      setEditingCard(null);
    }
  };
  
  const startEditing = (deck: any) => {
    setEditingDeck(deck.id);
    setEditDeckName(deck.name);
    setEditDeckDescription(deck.description);
  };
  
  const startEditingCard = (card: any) => {
    setEditingCard(card.id);
    setEditCardQuestion(card.question);
    setEditCardAnswer(card.answer);
  };
  
  const startStudying = () => {
    if (filteredCards.length > 0) {
      setIsStudying(true);
      setCurrentCardIndex(0);
      setShowAnswer(false);
    }
  };
  
  const handleNextCard = () => {
    if (currentCardIndex < studyCards.length - 1) {
      setCurrentCardIndex(currentCardIndex + 1);
      setShowAnswer(false);
    } else {
      // End of deck
      setIsStudying(false);
    }
  };
  
  const handlePrevCard = () => {
    if (currentCardIndex > 0) {
      setCurrentCardIndex(currentCardIndex - 1);
      setShowAnswer(false);
    }
  };
  
  const handleCardReview = (difficulty: 'easy' | 'medium' | 'hard') => {
    if (studyCards[currentCardIndex]) {
      updateCardReview(studyCards[currentCardIndex].id, difficulty);
      handleNextCard();
    }
  };
  
  const resetStudy = () => {
    setCurrentCardIndex(0);
    setShowAnswer(false);
  };
  
  return (
    <div className="bg-white rounded-xl shadow-sm overflow-hidden min-h-[calc(100vh-8rem)]">
      {isStudying ? (
        <div className="p-6 flex flex-col h-[calc(100vh-8rem)]">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-xl font-semibold text-gray-800">
              Studying: {decks.find(d => d.id === activeDeck)?.name}
            </h2>
            <div className="flex items-center space-x-2">
              <button
                onClick={() => setIsStudying(false)}
                className="px-3 py-1 text-sm text-gray-600 hover:text-gray-800"
              >
                Exit
              </button>
              <button
                onClick={resetStudy}
                className="flex items-center px-3 py-1 text-sm text-gray-600 hover:text-gray-800"
              >
                <RotateCcw className="w-4 h-4 mr-1" /> Reset
              </button>
            </div>
          </div>
          
          <div className="text-sm text-gray-500 mb-2">
            Card {currentCardIndex + 1} of {studyCards.length}
          </div>
          
          <div className="flex-1 flex flex-col">
            <div 
              className="flex-1 flex items-center justify-center p-8 bg-gradient-to-r from-indigo-50 to-purple-50 rounded-lg mb-4 cursor-pointer"
              onClick={() => setShowAnswer(!showAnswer)}
            >
              <div className="text-center">
                <div className="text-sm text-indigo-600 mb-2">
                  {showAnswer ? 'Answer' : 'Question'}
                </div>
                <div className="text-xl font-medium">
                  {showAnswer 
                    ? studyCards[currentCardIndex]?.answer 
                    : studyCards[currentCardIndex]?.question}
                </div>
                
                {!showAnswer && (
                  <div className="mt-4 text-sm text-gray-500">
                    Click to reveal answer
                  </div>
                )}
              </div>
            </div>
            
            <div className="flex justify-between items-center">
              <button
                onClick={handlePrevCard}
                disabled={currentCardIndex === 0}
                className={`flex items-center px-3 py-2 rounded-md ${
                  currentCardIndex === 0
                    ? 'text-gray-400 cursor-not-allowed'
                    : 'text-indigo-600 hover:bg-indigo-50'
                }`}
              >
                <ChevronLeft className="w-5 h-5 mr-1" /> Previous
              </button>
              
              {showAnswer ? (
                <div className="flex space-x-2">
                  <button
                    onClick={() => handleCardReview('hard')}
                    className="px-4 py-2 bg-red-100 text-red-700 rounded-md hover:bg-red-200"
                  >
                    Hard
                  </button>
                  <button
                    onClick={() => handleCardReview('medium')}
                    className="px-4 py-2 bg-yellow-100 text-yellow-700 rounded-md hover:bg-yellow-200"
                  >
                    Medium
                  </button>
                  <button
                    onClick={() => handleCardReview('easy')}
                    className="px-4 py-2 bg-green-100 text-green-700 rounded-md hover:bg-green-200"
                  >
                    Easy
                  </button>
                </div>
              ) : (
                <button
                  onClick={() => setShowAnswer(true)}
                  className="px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700"
                >
                  Show Answer
                </button>
              )}
              
              <button
                onClick={handleNextCard}
                disabled={currentCardIndex === studyCards.length - 1}
                className={`flex items-center px-3 py-2 rounded-md ${
                  currentCardIndex === studyCards.length - 1
                    ? 'text-gray-400 cursor-not-allowed'
                    : 'text-indigo-600 hover:bg-indigo-50'
                }`}
              >
                Next <ChevronRight className="w-5 h-5 ml-1" />
              </button>
            </div>
          </div>
        </div>
      ) : (
        <div className="p-4">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-xl font-semibold text-gray-800">Flashcards</h2>
            <button
              onClick={() => setIsCreatingDeck(true)}
              className="flex items-center px-3 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700"
            >
              <Plus className="w-4 h-4 mr-1" /> New Deck
            </button>
          </div>
          
          {isCreatingDeck && (
            <div className="mb-6 p-4 border border-gray-200 rounded-lg">
              <h3 className="text-lg font-medium mb-3">Create New Deck</h3>
              <div className="space-y-3">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Deck Name
                  </label>
                  <input
                    type="text"
                    value={newDeckName}
                    onChange={(e) => setNewDeckName(e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
                    placeholder="e.g., Aerospace Fundamentals"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Description
                  </label>
                  <textarea
                    value={newDeckDescription}
                    onChange={(e) => setNewDeckDescription(e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
                    placeholder="Brief description of this deck"
                    rows={3}
                  />
                </div>
                <div className="flex justify-end space-x-2">
                  <button
                    onClick={() => setIsCreatingDeck(false)}
                    className="px-4 py-2 border border-gray-300 text-gray-700 rounded-md hover:bg-gray-50"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={handleCreateDeck}
                    className="px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700"
                  >
                    Create Deck
                  </button>
                </div>
              </div>
            </div>
          )}
          
          {editingDeck && (
            <div className="mb-6 p-4 border border-gray-200 rounded-lg">
              <h3 className="text-lg font-medium mb-3">Edit Deck</h3>
              <div className="space-y-3">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Deck Name
                  </label>
                  <input
                    type="text"
                    value={editDeckName}
                    onChange={(e) => setEditDeckName(e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Description
                  </label>
                  <textarea
                    value={editDeckDescription}
                    onChange={(e) => setEditDeckDescription(e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
                    rows={3}
                  />
                </div>
                <div className="flex justify-end space-x-2">
                  <button
                    onClick={() => setEditingDeck(null)}
                    className="px-4 py-2 border border-gray-300 text-gray-700 rounded-md hover:bg-gray-50"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={handleUpdateDeck}
                    className="px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700"
                  >
                    Update Deck
                  </button>
                </div>
              </div>
            </div>
          )}
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {decks.length === 0 ? (
              <div className="col-span-full flex flex-col items-center justify-center py-12 text-gray-500">
                <BookOpen className="w-16 h-16 mb-4 text-gray-300" />
                <h3 className="text-lg font-medium mb-2">No flashcard decks yet</h3>
                <p className="mb-4 text-center">Create your first deck to start studying</p>
                <button
                  onClick={() => setIsCreatingDeck(true)}
                  className="flex items-center px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700"
                >
                  <Plus className="w-4 h-4 mr-2" /> Create a deck
                </button>
              </div>
            ) : (
              decks.map((deck) => (
                <div
                  key={deck.id}
                  className={`p-4 border rounded-lg transition-all ${
                    activeDeck === deck.id
                      ? 'border-indigo-500 bg-indigo-50'
                      : 'border-gray-200 hover:border-indigo-300 hover:bg-indigo-50/30'
                  }`}
                >
                  <div className="flex justify-between items-start">
                    <div 
                      className="cursor-pointer"
                      onClick={() => setActiveDeck(activeDeck === deck.id ? null : deck.id)}
                    >
                      <h3 className="text-lg font-medium text-gray-800">{deck.name}</h3>
                      <p className="text-sm text-gray-500 mt-1">{deck.description}</p>
                      <div className="flex items-center mt-2 text-sm text-gray-600">
                        <span>{deck.cardCount} cards</span>
                      </div>
                    </div>
                    <div className="flex space-x-1">
                      <button
                        onClick={() => startEditing(deck)}
                        className="p-1 text-gray-500 hover:text-indigo-600"
                      >
                        <Edit className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => deleteDeck(deck.id)}
                        className="p-1 text-gray-500 hover:text-red-600"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                  
                  {activeDeck === deck.id && (
                    <div className="mt-4">
                      <div className="flex justify-between items-center mb-3">
                        <h4 className="text-sm font-medium text-gray-700">Cards</h4>
                        <div className="flex space-x-2">
                          <button
                            onClick={() => setIsCreatingCard(true)}
                            className="flex items-center text-xs px-2 py-1 bg-indigo-100 text-indigo-700 rounded hover:bg-indigo-200"
                          >
                            <Plus className="w-3 h-3 mr-1" /> Add Card
                          </button>
                          {filteredCards.length > 0 && (
                            <button
                              onClick={startStudying}
                              className="flex items-center text-xs px-2 py-1 bg-green-100 text-green-700 rounded hover:bg-green-200"
                            >
                              <BookOpen className="w-3 h-3 mr-1" /> Study
                            </button>
                          )}
                        </div>
                      </div>
                      
                      {isCreatingCard && (
                        <div className="mb-3 p-3 bg-gray-50 rounded border border-gray-200">
                          <div className="space-y-2">
                            <div>
                              <label className="block text-xs font-medium text-gray-700 mb-1">
                                Question
                              </label>
                              <input
                                type="text"
                                value={newCardQuestion}
                                onChange={(e) => setNewCardQuestion(e.target.value)}
                                className="w-full px-2 py-1 text-sm border border-gray-300 rounded focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
                              />
                            </div>
                            <div>
                              <label className="block text-xs font-medium text-gray-700 mb-1">
                                Answer
                              </label>
                              <textarea
                                value={newCardAnswer}
                                onChange={(e) => setNewCardAnswer(e.target.value)}
                                className="w-full px-2 py-1 text-sm border border-gray-300 rounded focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
                                rows={2}
                              />
                            </div>
                            <div className="flex justify-end space-x-2">
                              <button
                                onClick={() => setIsCreatingCard(false)}
                                className="text-xs px-2 py-1 border border-gray-300 text-gray-700 rounded hover:bg-gray-50"
                              >
                                Cancel
                              </button>
                              <button
                                onClick={handleCreateCard}
                                className="text-xs px-2 py-1 bg-indigo-600 text-white rounded hover:bg-indigo-700"
                              >
                                Add
                              </button>
                            </div>
                          </div>
                        </div>
                      )}
                      
                      {editingCard && (
                        <div className="mb-3 p-3 bg-gray-50 rounded border border-gray-200">
                          <div className="space-y-2">
                            <div>
                              <label className="block text-xs font-medium text-gray-700 mb-1">
                                Question
                              </label>
                              <input
                                type="text"
                                value={editCardQuestion}
                                onChange={(e) => setEditCardQuestion(e.target.value)}
                                className="w-full px-2 py-1 text-sm border border-gray-300 rounded focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
                              />
                            </div>
                            <div>
                              <label className="block text-xs font-medium text-gray-700 mb-1">
                                Answer
                              </label>
                              <textarea
                                value={editCardAnswer}
                                onChange={(e) => setEditCardAnswer(e.target.value)}
                                className="w-full px-2 py-1 text-sm border border-gray-300 rounded focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
                                rows={2}
                              />
                            </div>
                            <div className="flex justify-end space-x-2">
                              <button
                                onClick={() => setEditingCard(null)}
                                className="text-xs px-2 py-1 border border-gray-300 text-gray-700 rounded hover:bg-gray-50"
                              >
                                Cancel
                              </button>
                              <button
                                onClick={handleUpdateCard}
                                className="text-xs px-2 py-1 bg-indigo-600 text-white rounded hover:bg-indigo-700"
                              >
                                Update
                              </button>
                            </div>
                          </div>
                        </div>
                      )}
                      
                      {filteredCards.length === 0 ? (
                        <div className="text-center py-4 text-sm text-gray-500">
                          No cards in this deck yet. Add some cards to start studying.
                        </div>
                      ) : (
                        <div className="space-y-2 max-h-60 overflow-y-auto">
                          {filteredCards.map((card) => (
                            <div 
                              key={card.id}
                              className="p-2 bg-white border border-gray-200 rounded-md hover:border-indigo-300"
                            >
                              <div className="flex justify-between">
                                <div>
                                  <div className="font-medium text-sm">{card.question}</div>
                                  <div className="text-xs text-gray-500 mt-1">{card.answer}</div>
                                </div>
                                <div className="flex space-x-1">
                                  <button
                                    onClick={() => startEditingCard(card)}
                                    className="p-1 text-gray-400 hover:text-indigo-600"
                                  >
                                    <Edit className="w-3 h-3" />
                                  </button>
                                  <button
                                    onClick={() => deleteCard(card.id)}
                                    className="p-1 text-gray-400 hover:text-red-600"
                                  >
                                    <Trash2 className="w-3 h-3" />
                                  </button>
                                </div>
                              </div>
                              {card.lastReviewed && (
                                <div className="mt-1 flex items-center">
                                  <span className={`inline-block w-2 h-2 rounded-full mr-1 ${
                                    card.difficulty === 'easy' ? 'bg-green-500' :
                                    card.difficulty === 'medium' ? 'bg-yellow-500' : 'bg-red-500'
                                  }`}></span>
                                  <span className="text-xs text-gray-400">
                                    Last reviewed: {new Date(card.lastReviewed).toLocaleDateString()}
                                  </span>
                                </div>
                              )}
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  )}
                </div>
              ))
            )}
          </div>
          
          <div className="mt-8 p-4 bg-indigo-50 rounded-lg">
            <h3 className="text-lg font-medium text-gray-800 mb-2">Study Tips</h3>
            <ul className="list-disc pl-5 text-sm text-gray-600 space-y-1">
              <li>Create separate decks for different aerospace engineering topics</li>
              <li>Keep questions clear and concise</li>
              <li>Review cards regularly to reinforce your memory</li>
              <li>Use the difficulty ratings to focus on challenging concepts</li>
              <li>Add diagrams or equations to your answers when needed</li>
            </ul>
          </div>
        </div>
      )}
    </div>
  );
};

export default FlashcardsPage;