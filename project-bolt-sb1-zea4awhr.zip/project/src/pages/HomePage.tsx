import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { BookText, Atom, Calculator, BookOpen, Users, ChevronRight } from 'lucide-react';

const HomePage = () => {
  const navigate = useNavigate();
  const [selectedTool, setSelectedTool] = useState('');
  
  const tools = [
    { id: 'notes', name: 'Notes', icon: <BookText className="w-6 h-6" />, path: '/notes', description: 'Take and organize your aerospace engineering notes' },
    { id: 'physics', name: 'Physics Simulator', icon: <Atom className="w-6 h-6" />, path: '/physics', description: 'Experiment with physics simulations' },
    { id: 'math', name: 'Math Calculator', icon: <Calculator className="w-6 h-6" />, path: '/math', description: 'Plot equations and solve complex problems' },
    { id: 'flashcards', name: 'Flashcards', icon: <BookOpen className="w-6 h-6" />, path: '/flashcards', description: 'Create and study with flashcards' },
    { id: 'community', name: 'Community', icon: <Users className="w-6 h-6" />, path: '/community', description: 'Connect with fellow aerospace students' },
  ];

  const handleToolSelect = (toolId: string) => {
    setSelectedTool(toolId);
    setTimeout(() => {
      const tool = tools.find(t => t.id === toolId);
      if (tool) navigate(tool.path);
    }, 300);
  };

  return (
    <div className="flex flex-col items-center justify-center min-h-[calc(100vh-4rem)] text-center px-4">
      <div className="max-w-3xl w-full">
        <h1 className="text-6xl md:text-7xl font-bold mb-6 font-display">
          <span className="block text-transparent bg-clip-text bg-gradient-to-r from-indigo-600 via-purple-500 to-pink-500">
            Hi, I'm Aero
          </span>
        </h1>
        
        <p className="text-xl text-gray-600 mb-12">
          Pick a tool you'd like to use:
        </p>
        
        <div className="relative w-full max-w-md mx-auto">
          <select
            value={selectedTool}
            onChange={(e) => handleToolSelect(e.target.value)}
            className="w-full py-3 px-4 pr-10 text-lg bg-white/50 backdrop-blur-sm border-2 border-indigo-300 rounded-full focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 appearance-none transition-all cursor-pointer"
          >
            <option value="" disabled>Select a tool...</option>
            {tools.map(tool => (
              <option key={tool.id} value={tool.id}>
                {tool.name}
              </option>
            ))}
          </select>
          <div className="absolute inset-y-0 right-0 flex items-center pr-3 pointer-events-none">
            <ChevronRight className="h-5 w-5 text-indigo-500" />
          </div>
        </div>
        
        <div className="mt-16 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {tools.map(tool => (
            <button
              key={tool.id}
              onClick={() => navigate(tool.path)}
              className="flex flex-col items-center p-6 bg-white/70 backdrop-blur-sm rounded-xl shadow-sm hover:shadow-md transition-all hover:bg-white/90 hover:scale-105"
            >
              <div className="p-3 rounded-full bg-gradient-to-r from-indigo-100 to-purple-100 mb-4">
                <div className="text-indigo-600">
                  {tool.icon}
                </div>
              </div>
              <h3 className="text-lg font-semibold mb-2">{tool.name}</h3>
              <p className="text-sm text-gray-600">{tool.description}</p>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};

export default HomePage;