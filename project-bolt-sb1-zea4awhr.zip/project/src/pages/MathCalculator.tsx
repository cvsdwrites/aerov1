import React, { useEffect, useRef, useState } from 'react';
import functionPlot from 'function-plot';
import ReactMarkdown from 'react-markdown';
import remarkMath from 'remark-math';
import rehypeKatex from 'rehype-katex';
import 'katex/dist/katex.min.css';
import { Calculator, Trash2, Save, Plus, ChevronDown, ChevronUp } from 'lucide-react';

const MathCalculator = () => {
  const plotRef = useRef<HTMLDivElement>(null);
  const [equation, setEquation] = useState('x^2');
  const [xMin, setXMin] = useState(-10);
  const [xMax, setXMax] = useState(10);
  const [yMin, setYMin] = useState(-10);
  const [yMax, setYMax] = useState(10);
  const [savedEquations, setSavedEquations] = useState<string[]>([]);
  const [showCalculator, setShowCalculator] = useState(false);
  const [calculatorInput, setCalculatorInput] = useState('');
  const [calculatorResult, setCalculatorResult] = useState('');
  const [calculatorHistory, setCalculatorHistory] = useState<{input: string, result: string}[]>([]);
  const [showAdvancedOptions, setShowAdvancedOptions] = useState(false);
  const [gridEnabled, setGridEnabled] = useState(true);
  const [derivativeEnabled, setDerivativeEnabled] = useState(false);

  // Plot the function
  useEffect(() => {
    if (plotRef.current) {
      try {
        plotRef.current.innerHTML = '';
        
        const width = plotRef.current.clientWidth;
        const height = 400;
        
        const functions = [{
          fn: equation,
          color: '#6366f1'
        }];
        
        // Add derivative if enabled
        if (derivativeEnabled && equation) {
          functions.push({
            derivative: {
              fn: equation,
              order: 1
            },
            color: '#ec4899',
            graphType: 'polyline'
          });
        }
        
        functionPlot({
          target: plotRef.current,
          width,
          height,
          grid: gridEnabled,
          xAxis: {
            domain: [xMin, xMax]
          },
          yAxis: {
            domain: [yMin, yMax]
          },
          data: functions
        });
      } catch (error) {
        console.error('Error plotting function:', error);
      }
    }
  }, [equation, xMin, xMax, yMin, yMax, gridEnabled, derivativeEnabled]);

  // Handle window resize
  useEffect(() => {
    const handleResize = () => {
      if (plotRef.current) {
        try {
          plotRef.current.innerHTML = '';
          
          const width = plotRef.current.clientWidth;
          const height = 400;
          
          const functions = [{
            fn: equation,
            color: '#6366f1'
          }];
          
          if (derivativeEnabled && equation) {
            functions.push({
              derivative: {
                fn: equation,
                order: 1
              },
              color: '#ec4899',
              graphType: 'polyline'
            });
          }
          
          functionPlot({
            target: plotRef.current,
            width,
            height,
            grid: gridEnabled,
            xAxis: {
              domain: [xMin, xMax]
            },
            yAxis: {
              domain: [yMin, yMax]
            },
            data: functions
          });
        } catch (error) {
          console.error('Error resizing plot:', error);
        }
      }
    };

    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, [equation, xMin, xMax, yMin, yMax, gridEnabled, derivativeEnabled]);

  const saveEquation = () => {
    if (equation && !savedEquations.includes(equation)) {
      setSavedEquations([...savedEquations, equation]);
    }
  };

  const loadEquation = (eq: string) => {
    setEquation(eq);
  };

  const deleteEquation = (index: number) => {
    const newSavedEquations = [...savedEquations];
    newSavedEquations.splice(index, 1);
    setSavedEquations(newSavedEquations);
  };

  const calculateResult = () => {
    try {
      // Use Function constructor to evaluate the expression
      // This is a simple approach - in a production app, you'd want a more robust math parser
      const result = new Function('return ' + calculatorInput.replace(/\^/g, '**'))();
      setCalculatorResult(result.toString());
      setCalculatorHistory([...calculatorHistory, {
        input: calculatorInput,
        result: result.toString()
      }]);
      setCalculatorInput('');
    } catch (error) {
      setCalculatorResult('Error in calculation');
    }
  };

  const clearCalculatorHistory = () => {
    setCalculatorHistory([]);
    setCalculatorResult('');
  };

  return (
    <div className="bg-white rounded-xl shadow-sm overflow-hidden">
      <div className="p-4 border-b border-gray-200">
        <h2 className="text-xl font-semibold text-gray-800">Math Calculator</h2>
        <p className="text-gray-600 text-sm mt-1">
          Plot functions and perform calculations
        </p>
      </div>
      
      <div className="p-4">
        <div className="mb-4">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1">
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Function f(x) =
              </label>
              <div className="flex">
                <input
                  type="text"
                  value={equation}
                  onChange={(e) => setEquation(e.target.value)}
                  placeholder="e.g., x^2, sin(x), x^3-2*x"
                  className="flex-1 px-3 py-2 border border-gray-300 rounded-l-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
                />
                <button
                  onClick={saveEquation}
                  className="px-3 py-2 bg-indigo-600 text-white rounded-r-md hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
                >
                  <Save className="h-5 w-5" />
                </button>
              </div>
              <div className="text-xs text-gray-500 mt-1">
                Use standard math notation: x^2, sin(x), cos(x), tan(x), sqrt(x), etc.
              </div>
            </div>
            
            <div className="md:w-64">
              <button
                onClick={() => setShowAdvancedOptions(!showAdvancedOptions)}
                className="w-full flex justify-between items-center px-3 py-2 border border-gray-300 rounded-md text-sm text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
              >
                <span>Graph Options</span>
                {showAdvancedOptions ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
              </button>
            </div>
          </div>
        </div>
        
        {showAdvancedOptions && (
          <div className="mb-4 p-4 bg-gray-50 rounded-lg">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  X Min
                </label>
                <input
                  type="number"
                  value={xMin}
                  onChange={(e) => setXMin(Number(e.target.value))}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  X Max
                </label>
                <input
                  type="number"
                  value={xMax}
                  onChange={( e) => setXMax(Number(e.target.value))}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Y Min
                </label>
                <input
                  type="number"
                  value={yMin}
                  onChange={(e) => setYMin(Number(e.target.value))}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Y Max
                </label>
                <input
                  type="number"
                  value={yMax}
                  onChange={(e) => setYMax(Number(e.target.value))}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
                />
              </div>
            </div>
            
            <div className="mt-4 flex items-center space-x-6">
              <label className="flex items-center">
                <input
                  type="checkbox"
                  checked={gridEnabled}
                  onChange={(e) => setGridEnabled(e.target.checked)}
                  className="h-4 w-4 text-indigo-600 focus:ring-indigo-500 border-gray-300 rounded"
                />
                <span className="ml-2 text-sm text-gray-700">Show Grid</span>
              </label>
              
              <label className="flex items-center">
                <input
                  type="checkbox"
                  checked={derivativeEnabled}
                  onChange={(e) => setDerivativeEnabled(e.target.checked)}
                  className="h-4 w-4 text-indigo-600 focus:ring-indigo-500 border-gray-300 rounded"
                />
                <span className="ml-2 text-sm text-gray-700">Show Derivative</span>
              </label>
            </div>
          </div>
        )}
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="md:col-span-2">
            <div 
              ref={plotRef} 
              className="w-full h-[400px] border border-gray-200 rounded-lg overflow-hidden bg-gray-50"
            ></div>
            
            <div className="mt-4">
              <button
                onClick={() => setShowCalculator(!showCalculator)}
                className="flex items-center px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
              >
                <Calculator className="h-5 w-5 mr-2" />
                {showCalculator ? 'Hide Calculator' : 'Show Calculator'}
              </button>
              
              {showCalculator && (
                <div className="mt-4 p-4 border border-gray-200 rounded-lg">
                  <div className="flex mb-4">
                    <input
                      type="text"
                      value={calculatorInput}
                      onChange={(e) => setCalculatorInput(e.target.value)}
                      onKeyPress={(e) => e.key === 'Enter' && calculateResult()}
                      placeholder="Enter calculation (e.g., 2+2, sin(30), 5^2)"
                      className="flex-1 px-3 py-2 border border-gray-300 rounded-l-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
                    />
                    <button
                      onClick={calculateResult}
                      className="px-4 py-2 bg-indigo-600 text-white rounded-r-md hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
                    >
                      Calculate
                    </button>
                  </div>
                  
                  {calculatorResult && (
                    <div className="mb-4 p-3 bg-gray-50 rounded-md">
                      <div className="text-sm text-gray-500">Result:</div>
                      <div className="text-lg font-medium">{calculatorResult}</div>
                    </div>
                  )}
                  
                  {calculatorHistory.length > 0 && (
                    <div>
                      <div className="flex justify-between items-center mb-2">
                        <h3 className="text-sm font-medium text-gray-700">History</h3>
                        <button
                          onClick={clearCalculatorHistory}
                          className="text-xs text-red-600 hover:text-red-800"
                        >
                          Clear History
                        </button>
                      </div>
                      
                      <div className="max-h-40 overflow-y-auto">
                        {calculatorHistory.map((item, index) => (
                          <div 
                            key={index} 
                            className="text-sm p-2 hover:bg-gray-50 border-b border-gray-100 cursor-pointer"
                            onClick={() => setCalculatorInput(item.input)}
                          >
                            <div>{item.input} = <span className="font-medium">{item.result}</span></div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
          
          <div>
            <div className="border border-gray-200 rounded-lg overflow-hidden">
              <div className="bg-gray-50 px-4 py-2 border-b border-gray-200 flex justify-between items-center">
                <h3 className="text-sm font-medium text-gray-700">Saved Functions</h3>
                {savedEquations.length > 0 && (
                  <button
                    onClick={() => setSavedEquations([])}
                    className="text-xs text-red-600 hover:text-red-800"
                  >
                    Clear All
                  </button>
                )}
              </div>
              
              <div className="p-4">
                {savedEquations.length === 0 ? (
                  <div className="text-center py-4 text-sm text-gray-500">
                    No saved functions yet. Save a function to see it here.
                  </div>
                ) : (
                  <ul className="space-y-2">
                    {savedEquations.map((eq, index) => (
                      <li key={index} className="flex justify-between items-center p-2 hover:bg-gray-50 rounded-md">
                        <button
                          onClick={() => loadEquation(eq)}
                          className="text-left text-sm text-indigo-600 hover:text-indigo-800"
                        >
                          f(x) = {eq}
                        </button>
                        <button
                          onClick={() => deleteEquation(index)}
                          className="text-gray-400 hover:text-red-500"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </li>
                    ))}
                  </ul>
                )}
                
                <div className="mt-4">
                  <h4 className="text-sm font-medium text-gray-700 mb-2">Common Functions</h4>
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      onClick={() => setEquation('x^2')}
                      className="text-xs px-2 py-1 bg-gray-100 hover:bg-gray-200 rounded text-gray-700"
                    >
                      f(x) = x²
                    </button>
                    <button
                      onClick={() => setEquation('sin(x)')}
                      className="text-xs px-2 py-1 bg-gray-100 hover:bg-gray-200 rounded text-gray-700"
                    >
                      f(x) = sin(x)
                    </button>
                    <button
                      onClick={() => setEquation('cos(x)')}
                      className="text-xs px-2 py-1 bg-gray-100 hover:bg-gray-200 rounded text-gray-700"
                    >
                      f(x) = cos(x)
                    </button>
                    <button
                      onClick={() => setEquation('tan(x)')}
                      className="text-xs px-2 py-1 bg-gray-100 hover:bg-gray-200 rounded text-gray-700"
                    >
                      f(x) = tan(x)
                    </button>
                    <button
                      onClick={() => setEquation('x^3')}
                      className="text-xs px-2 py-1 bg-gray-100 hover:bg-gray-200 rounded text-gray-700"
                    >
                      f(x) = x³
                    </button>
                    <button
                      onClick={() => setEquation('sqrt(x)')}
                      className="text-xs px-2 py-1 bg-gray-100 hover:bg-gray-200 rounded text-gray-700"
                    >
                      f(x) = √x
                    </button>
                    <button
                      onClick={() => setEquation('1/x')}
                      className="text-xs px-2 py-1 bg-gray-100 hover:bg-gray-200 rounded text-gray-700"
                    >
                      f(x) = 1/x
                    </button>
                    <button
                      onClick={() => setEquation('e^x')}
                      className="text-xs px-2 py-1 bg-gray-100 hover:bg-gray-200 rounded text-gray-700"
                    >
                      f(x) = eˣ
                    </button>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="mt-4 border border-gray-200 rounded-lg overflow-hidden">
              <div className="bg-gray-50 px-4 py-2 border-b border-gray-200">
                <h3 className="text-sm font-medium text-gray-700">Formula Reference</h3>
              </div>
              
              <div className="p-4 max-h-80 overflow-y-auto">
                <ReactMarkdown
                  remarkPlugins={[remarkMath]}
                  rehypePlugins={[rehypeKatex]}
                  className="text-sm"
                >
                  {`
### Basic Operations
- Addition: \`a + b\`
- Subtraction: \`a - b\`
- Multiplication: \`a * b\`
- Division: \`a / b\`
- Exponentiation: \`a^b\` or \`a**b\`

### Trigonometric Functions
- Sine: \`sin(x)\`
- Cosine: \`cos(x)\`
- Tangent: \`tan(x)\`

### Other Functions
- Square root: \`sqrt(x)\`
- Absolute value: \`abs(x)\`
- Exponential: \`exp(x)\` or \`e^x\`
- Natural logarithm: \`log(x)\`
- Base-10 logarithm: \`log10(x)\`

### Constants
- Pi: \`PI\` or \`π\`
- Euler's number: \`E\` or \`e\`

### Aerospace Formulas

#### Lift Equation
$L = \\frac{1}{2} \\rho v^2 S C_L$

#### Drag Equation
$D = \\frac{1}{2} \\rho v^2 S C_D$

#### Rocket Equation
$\\Delta v = v_e \\ln\\frac{m_0}{m_f}$

#### Reynolds Number
$Re = \\frac{\\rho v L}{\\mu}$
                  `}
                </ReactMarkdown>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MathCalculator;