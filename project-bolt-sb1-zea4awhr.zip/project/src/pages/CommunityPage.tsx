import React, { useState } from 'react';
import { useCommunityStore } from '../store/communityStore';
import { Users, MessageSquare, Heart, Send, Edit, Trash2, Tag, Plus, Search } from 'lucide-react';

const CommunityPage = () => {
  const { 
    posts, 
    currentUser, 
    addPost, 
    updatePost, 
    deletePost, 
    likePost, 
    addComment, 
    deleteComment, 
    likeComment,
    setCurrentUser 
  } = useCommunityStore();
  
  const [newPostTitle, setNewPostTitle] = useState('');
  const [newPostContent, setNewPostContent] = useState('');
  const [newPostTags, setNewPostTags] = useState('');
  const [isCreatingPost, setIsCreatingPost] = useState(false);
  
  const [editingPost, setEditingPost] = useState<string | null>(null);
  const [editPostTitle, setEditPostTitle] = useState('');
  const [editPostContent, setEditPostContent] = useState('');
  const [editPostTags, setEditPostTags] = useState('');
  
  const [newComments, setNewComments] = useState<{[key: string]: string}>({});
  const [searchQuery, setSearchQuery] = useState('');
  const [username, setUsername] = useState(currentUser);
  const [isEditingUsername, setIsEditingUsername] = useState(false);
  
  const handleCreatePost = () => {
    if (newPostTitle.trim() && newPostContent.trim()) {
      const tags = newPostTags
        .split(',')
        .map(tag => tag.trim())
        .filter(tag => tag.length > 0);
      
      addPost({
        title: newPostTitle,
        content: newPostContent,
        author: currentUser,
        tags
      });
      
      setNewPostTitle('');
      setNewPostContent('');
      setNewPostTags('');
      setIsCreatingPost(false);
    }
  };
  
  const handleUpdatePost = () => {
    if (editingPost && editPostTitle.trim() && editPostContent.trim()) {
      const tags = editPostTags
        .split(',')
        .map(tag => tag.trim())
        .filter(tag => tag.length > 0);
      
      updatePost(editingPost, {
        title: editPostTitle,
        content: editPostContent,
        tags
      });
      
      setEditingPost(null);
    }
  };
  
  const startEditingPost = (post: any) => {
    setEditingPost(post.id);
    setEditPostTitle(post.title);
    setEditPostContent(post.content);
    setEditPostTags(post.tags.join(', '));
  };
  
  const handleAddComment = (postId: string) => {
    const commentContent = newComments[postId];
    if (commentContent && commentContent.trim()) {
      addComment(postId, {
        content: commentContent,
        author: currentUser
      });
      
      setNewComments(prev => ({
        ...prev,
        [postId]: ''
      }));
    }
  };
  
  const handleUpdateUsername = () => {
    if (username.trim()) {
      setCurrentUser(username);
      setIsEditingUsername(false);
    }
  };
  
  const filteredPosts = posts.filter(post => {
    if (!searchQuery) return true;
    
    const query = searchQuery.toLowerCase();
    return (
      post.title.toLowerCase().includes(query) ||
      post.content.toLowerCase().includes(query) ||
      post.author.toLowerCase().includes(query) ||
      post.tags.some(tag => tag.toLowerCase().includes(query))
    );
  });
  
  return (
    <div className="bg-white rounded-xl shadow-sm overflow-hidden min-h-[calc(100vh-8rem)]">
      <div className="p-4 border-b border-gray-200">
        <h2 className="text-xl font-semibold text-gray-800">Community</h2>
        <p className="text-gray-600 text-sm mt-1">
          Connect with fellow aerospace engineering students
        </p>
      </div>
      
      <div className="p-4">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6 gap-4">
          <div className="flex-1">
            <div className="relative">
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search posts, topics, or users..."
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
              />
              <Search className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" />
            </div>
          </div>
          
          <div className="flex items-center space-x-4">
            {isEditingUsername ? (
              <div className="flex items-center space-x-2">
                <input
                  type="text"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  className="px-3 py-1 text-sm border border-gray-300 rounded-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
                  placeholder="Your username"
                />
                <button
                  onClick={handleUpdateUsername}
                  className="text-xs px-2 py-1 bg-indigo-600 text-white rounded-md hover:bg-indigo-700"
                >
                  Save
                </button>
              </div>
            ) : (
              <div className="flex items-center space-x-2">
                <span className="text-sm text-gray-600">
                  Posting as: <span className="font-medium">{currentUser}</span>
                </span>
                <button
                  onClick={() => setIsEditingUsername(true)}
                  className="text-xs text-indigo-600 hover:text-indigo-800"
                >
                  Change
                </button>
              </div>
            )}
            
            <button
              onClick={() => setIsCreatingPost(true)}
              className="flex items-center px-3 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700"
            >
              <Plus className="w-4 h-4 mr-1" /> New Post
            </button>
          </div>
        </div>
        
        {isCreatingPost && (
          <div className="mb-6 p-4 border border-gray-200 rounded-lg">
            <h3 className="text-lg font-medium mb-3">Create New Post</h3>
            <div className="space-y-3">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Title
                </label>
                <input
                  type="text"
                  value={newPostTitle}
                  onChange={(e) => setNewPostTitle(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
                  placeholder="e.g., Question about fluid dynamics"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Content
                </label>
                <textarea
                  value={newPostContent}
                  onChange={(e) => setNewPostContent(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
                  placeholder="Describe your question or share your thoughts..."
                  rows={5}
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Tags (comma separated)
                </label>
                <input
                  type="text"
                  value={newPostTags}
                  onChange={(e) => setNewPostTags(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
                  placeholder="e.g., aerodynamics, homework, fluid mechanics"
                />
              </div>
              <div className="flex justify-end space-x-2">
                <button
                  onClick={() => setIsCreatingPost(false)}
                  className="px-4 py-2 border border-gray-300 text-gray-700 rounded-md hover:bg-gray-50"
                >
                  Cancel
                </button>
                <button
                  onClick={handleCreatePost}
                  className="px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700"
                >
                  Post
                </button>
              </div>
            </div>
          </div>
        )}
        
        {editingPost && (
          <div className="mb-6 p-4 border border-gray-200 rounded-lg">
            <h3 className="text-lg font-medium mb-3">Edit Post</h3>
            <div className="space-y-3">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Title
                </label>
                <input
                  type="text"
                  value={editPostTitle}
                  onChange={(e) => setEditPostTitle(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Content
                </label>
                <textarea
                  value={editPostContent}
                  onChange={(e) => setEditPostContent(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
                  rows={5}
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Tags (comma separated)
                </label>
                <input
                  type="text"
                  value={editPostTags}
                  onChange={(e) => setEditPostTags(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
                />
              </div>
              <div className="flex justify-end space-x-2">
                <button
                  onClick={() => setEditingPost(null)}
                  className="px-4 py-2 border border-gray-300 text-gray-700 rounded-md hover:bg-gray-50"
                >
                  Cancel
                </button>
                <button
                  onClick={handleUpdatePost}
                  className="px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700"
                >
                  Update
                </button>
              </div>
            </div>
          </div>
        )}
        
        {filteredPosts.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-12 text-gray-500">
            {searchQuery ? (
              <>
                <Search className="w-16 h-16 mb-4 text-gray-300" />
                <h3 className="text-lg font-medium mb-2">No matching posts found</h3>
                <p className="mb-4 text-center">Try different search terms or clear your search</p>
                <button
                  onClick={() => setSearchQuery('')}
                  className="px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700"
                >
                  Clear Search
                </button>
              </>
            ) : (
              <>
                <Users className="w-16 h-16 mb-4 text-gray-300" />
                <h3 className="text-lg font-medium mb-2">No posts yet</h3>
                <p className="mb-4 text-center">Be the first to start a discussion!</p>
                <button
                  onClick={() => setIsCreatingPost(true)}
                  className="flex items-center px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700"
                >
                  <Plus className="w-4 h-4 mr-2" /> Create a post
                </button>
              </>
            )}
          </div>
        ) : (
          <div className="space-y-6">
            {filteredPosts.map((post) => (
              <div key={post.id} className="border border-gray-200 rounded-lg overflow-hidden">
                <div className="p-4">
                  <div className="flex justify-between items-start">
                    <h3 className="text-lg font-medium text-gray-800">{post.title}</h3>
                    {post.author === currentUser && (
                      <div className="flex space-x-1">
                        <button
                          onClick={() => startEditingPost(post)}
                          className="p-1 text-gray-500 hover:text-indigo-600"
                        >
                          <Edit className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => deletePost(post.id)}
                          className="p-1 text-gray-500 hover:text-red-600"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    )}
                  </div>
                  
                  <div className="flex items-center text-sm text-gray-500 mt-1">
                    <span className="font-medium text-gray-700">{post.author}</span>
                    <span className="mx-2">•</span>
                    <span>{new Date(post.createdAt).toLocaleDateString()}</span>
                    {post.createdAt !== post.updatedAt && (
                      <>
                        <span className="mx-2">•</span>
                        <span>Edited: {new Date(post.updatedAt).toLocaleDateString()}</span>
                      </>
                    )}
                  </div>
                  
                  <div className="mt-3 text-gray-700 whitespace-pre-line">
                    {post.content}
                  </div>
                  
                  {post.tags.length > 0 && (
                    <div className="flex flex-wrap gap-1 mt-3">
                      {post.tags.map((tag, index) => (
                        <span 
                          key={index}
                          className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-indigo-100 text-indigo-800"
                        >
                          <Tag className="w-3 h-3 mr-1" />
                          {tag}
                        </span>
                      ))}
                    </div>
                  )}
                  
                  <div className="flex items-center mt-4 space-x-4">
                    <button
                      onClick={() => likePost(post.id)}
                      className="flex items-center text-sm text-gray-500 hover:text-indigo-600"
                    >
                      <Heart className="w-4 h-4 mr-1" />
                      {post.likes} {post.likes === 1 ? 'Like' : 'Likes'}
                    </button>
                    <div className="flex items-center text-sm text-gray-500">
                      <MessageSquare className="w-4 h-4 mr-1" />
                      {post.comments.length} {post.comments.length === 1 ? 'Comment' : 'Comments'}
                    </div>
                  </div>
                </div>
                
                {post.comments.length > 0 && (
                  <div className="border-t border-gray-100 bg-gray-50">
                    <div className="p-4 space-y-3">
                      {post.comments.map((comment) => (
                        <div key={comment.id} className="flex space-x-3">
                          <div className="flex-shrink-0 w-8 h-8 rounded-full bg-indigo-100 flex items-center justify-center text-indigo-500">
                            {comment.author.charAt(0).toUpperCase()}
                          </div>
                          <div className="flex-1">
                            <div className="flex justify-between items-start">
                              <div>
                                <span className="font-medium text-sm text-gray-700">{comment.author}</span>
                                <span className="text-xs text-gray-500 ml-2">
                                  {new Date(comment.createdAt).toLocaleDateString()}
                                </span>
                              </div>
                              {comment.author === currentUser && (
                                <button
                                  onClick={() => deleteComment(post.id, comment.id)}
                                  className="p-1 text-gray-400 hover:text-red-600"
                                >
                                  <Trash2 className="w-3 h-3" />
                                </button>
                              )}
                            </div>
                            <div className="mt-1 text-sm text-gray-700">
                              {comment.content}
                            </div>
                            <button
                              onClick={() => likeComment(post.id, comment.id)}
                              className="mt-1 flex items-center text-xs text-gray-500 hover:text-indigo-600"
                            >
                              <Heart className="w-3 h-3 mr-1" />
                              {comment.likes} {comment.likes === 1 ? 'Like' : 'Likes'}
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
                
                <div className="border-t border-gray-200 p-4">
                  <div className="flex space-x-3">
                    <div className="flex-shrink-0 w-8 h-8 rounded-full bg-indigo-100 flex items-center justify-center text-indigo-500">
                      {currentUser.charAt(0).toUpperCase()}
                    </div>
                    <div className="flex-1 relative">
                      <input
                        type="text"
                        value={newComments[post.id] || ''}
                        onChange={(e) => setNewComments({
                          ...newComments,
                          [post.id]: e.target.value
                        })}
                        placeholder="Write a comment..."
                        className="w-full pr-10 pl-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
                        onKeyPress={(e) => {
                          if (e.key === 'Enter') {
                            handleAddComment(post.id);
                          }
                        }}
                      />
                      <button
                        onClick={() => handleAddComment(post.id)}
                        className="absolute right-2 top-2 text-indigo-600 hover:text-indigo-800"
                      >
                        <Send className="w-5 h-5" />
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
        
        <div className="mt-8 p-4 bg-indigo-50 rounded-lg">
          <h3 className="text-lg font-medium text-gray-800 mb-2">Community Guidelines</h3>
          <ul className="list-disc pl-5 text-sm text-gray-600 space-y-1">
            <li>Be respectful and supportive of your fellow aerospace engineering students</li>
            <li>Share knowledge and resources that might help others</li>
            <li>Ask clear, specific questions to get better answers</li>
            <li>Use appropriate tags to categorize your posts</li>
            <li>Give credit when sharing others' work or ideas</li>
          </ul>
        </div>
      </div>
    </div>
  );
};

export default CommunityPage;