import React, { useState, useEffect } from 'react';
import { PlusCircle, Folder, File, Trash2, Save } from 'lucide-react';
import { useNotesStore } from '../store/notesStore';

const NotesPage = () => {
  const { notes, folders, addNote, addFolder, updateNote, deleteNote, deleteFolder } = useNotesStore();
  const [activeNote, setActiveNote] = useState<string | null>(null);
  const [activeFolder, setActiveFolder] = useState<string | null>(null);
  const [noteTitle, setNoteTitle] = useState('');
  const [noteContent, setNoteContent] = useState('');
  const [newFolderName, setNewFolderName] = useState('');
  const [isCreatingFolder, setIsCreatingFolder] = useState(false);

  useEffect(() => {
    if (activeNote) {
      const note = notes.find(n => n.id === activeNote);
      if (note) {
        setNoteTitle(note.title);
        setNoteContent(note.content);
      }
    } else {
      setNoteTitle('');
      setNoteContent('');
    }
  }, [activeNote, notes]);

  const handleNewNote = () => {
    const id = Date.now().toString();
    addNote({
      id,
      title: 'Untitled Note',
      content: '',
      folderId: activeFolder,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    });
    setActiveNote(id);
  };

  const handleSaveNote = () => {
    if (activeNote) {
      updateNote(activeNote, { title: noteTitle, content: noteContent, updatedAt: new Date().toISOString() });
    }
  };

  const handleCreateFolder = () => {
    if (newFolderName.trim()) {
      addFolder({
        id: Date.now().toString(),
        name: newFolderName,
        createdAt: new Date().toISOString()
      });
      setNewFolderName('');
      setIsCreatingFolder(false);
    }
  };

  const filteredNotes = activeFolder 
    ? notes.filter(note => note.folderId === activeFolder)
    : notes.filter(note => !note.folderId);

  return (
    <div className="bg-white rounded-xl shadow-sm overflow-hidden min-h-[calc(100vh-8rem)]">
      <div className="flex h-[calc(100vh-8rem)]">
        {/* Sidebar */}
        <div className="w-64 bg-gray-50 border-r border-gray-200 flex flex-col">
          <div className="p-4 border-b border-gray-200">
            <h2 className="text-lg font-semibold text-gray-800">Notes</h2>
          </div>
          
          <div className="p-3 flex justify-between items-center">
            <button 
              onClick={handleNewNote}
              className="flex items-center text-sm text-indigo-600 hover:text-indigo-800"
            >
              <PlusCircle className="w-4 h-4 mr-1" /> New Note
            </button>
            <button 
              onClick={() => setIsCreatingFolder(true)}
              className="flex items-center text-sm text-indigo-600 hover:text-indigo-800"
            >
              <Folder className="w-4 h-4 mr-1" /> New Folder
            </button>
          </div>

          {isCreatingFolder && (
            <div className="px-3 py-2">
              <div className="flex items-center space-x-2">
                <input
                  type="text"
                  value={newFolderName}
                  onChange={(e) => setNewFolderName(e.target.value)}
                  placeholder="Folder name"
                  className="flex-1 text-sm border border-gray-300 rounded px-2 py-1"
                  autoFocus
                />
                <button 
                  onClick={handleCreateFolder}
                  className="text-xs bg-indigo-600 text-white px-2 py-1 rounded hover:bg-indigo-700"
                >
                  Add
                </button>
              </div>
            </div>
          )}

          <div className="overflow-y-auto flex-1">
            {/* Folders */}
            {folders.map(folder => (
              <div key={folder.id} className="px-3 py-2">
                <div 
                  className={`flex items-center justify-between p-2 rounded-md cursor-pointer ${activeFolder === folder.id ? 'bg-indigo-100' : 'hover:bg-gray-100'}`}
                  onClick={() => setActiveFolder(folder.id)}
                >
                  <div className="flex items-center">
                    <Folder className="w-4 h-4 mr-2 text-indigo-600" />
                    <span className="text-sm">{folder.name}</span>
                  </div>
                  <button 
                    onClick={(e) => {
                      e.stopPropagation();
                      deleteFolder(folder.id);
                      if (activeFolder === folder.id) setActiveFolder(null);
                    }}
                    className="text-gray-400 hover:text-red-500"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
                
                {/* Notes in this folder */}
                {activeFolder === folder.id && 
                  notes.filter(note => note.folderId === folder.id).map(note => (
                    <div 
                      key={note.id}
                      className={`ml-4 flex items-center justify-between p-2 rounded-md cursor-pointer ${activeNote === note.id ? 'bg-indigo-100' : 'hover:bg-gray-100'}`}
                      onClick={() => setActiveNote(note.id)}
                    >
                      <div className="flex items-center">
                        <File className="w-4 h-4 mr-2 text-gray-500" />
                        <span className="text-sm truncate">{note.title}</span>
                      </div>
                      <button 
                        onClick={(e) => {
                          e.stopPropagation();
                          deleteNote(note.id);
                          if (activeNote === note.id) setActiveNote(null);
                        }}
                        className="text-gray-400 hover:text-red-500"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  ))
                }
              </div>
            ))}
            
            {/* Uncategorized notes */}
            <div className="px-3 py-2">
              <div 
                className={`flex items-center p-2 rounded-md cursor-pointer ${activeFolder === null ? 'bg-indigo-100' : 'hover:bg-gray-100'}`}
                onClick={() => setActiveFolder(null)}
              >
                <File className="w-4 h-4 mr-2 text-gray-500" />
                <span className="text-sm">Uncategorized</span>
              </div>
              
              {activeFolder === null && 
                notes.filter(note => !note.folderId).map(note => (
                  <div 
                    key={note.id}
                    className={`ml-4 flex items-center justify-between p-2 rounded-md cursor-pointer ${activeNote === note.id ? 'bg-indigo-100' : 'hover:bg-gray-100'}`}
                    onClick={() => setActiveNote(note.id)}
                  >
                    <div className="flex items-center">
                      <File className="w-4 h-4 mr-2 text-gray-500" />
                      <span className="text-sm truncate">{note.title}</span>
                    </div>
                    <button 
                      onClick={(e) => {
                        e.stopPropagation();
                        deleteNote(note.id);
                        if (activeNote === note.id) setActiveNote(null);
                      }}
                      className="text-gray-400 hover:text-red-500"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                ))
              }
            </div>
          </div>
        </div>
        
        {/* Note Editor */}
        <div className="flex-1 flex flex-col">
          {activeNote ? (
            <>
              <div className="p-4 border-b border-gray-200 flex justify-between items-center">
                <input
                  type="text"
                  value={noteTitle}
                  onChange={(e) => setNoteTitle(e.target.value)}
                  className="text-xl font-semibold bg-transparent border-none focus:outline-none focus:ring-0 w-full"
                  placeholder="Note title"
                />
                <button 
                  onClick={handleSaveNote}
                  className="flex items-center text-sm bg-indigo-600 text-white px-3 py-1 rounded-md hover:bg-indigo-700"
                >
                  <Save className="w-4 h-4 mr-1" /> Save
                </button>
              </div>
              <div className="flex-1 p-4 overflow-auto">
                <textarea
                  value={noteContent}
                  onChange={(e) => setNoteContent(e.target.value)}
                  className="w-full h-full p-2 border border-gray-200 rounded-md focus:outline-none focus:ring-1 focus:ring-indigo-500 resize-none"
                  placeholder="Start writing your note here..."
                />
              </div>
            </>
          ) : (
            <div className="flex-1 flex items-center justify-center text-gray-500">
              <div className="text-center">
                <File className="w-16 h-16 mx-auto mb-4 text-gray-300" />
                <h3 className="text-xl font-medium mb-2">No note selected</h3>
                <p className="mb-4">Select a note from the sidebar or create a new one</p>
                <button 
                  onClick={handleNewNote}
                  className="inline-flex items-center text-sm bg-indigo-600 text-white px-4 py-2 rounded-md hover:bg-indigo-700"
                >
                  <PlusCircle className="w-4 h-4 mr-2" /> Create a new note
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default NotesPage;