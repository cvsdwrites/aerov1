import React, { useEffect, useRef, useState } from 'react';
import Matter from 'matter-js';
import { Play, Pause, RotateCcw, Settings } from 'lucide-react';

const PhysicsSimulator = () => {
  const sceneRef = useRef<HTMLDivElement>(null);
  const engineRef = useRef<Matter.Engine | null>(null);
  const renderRef = useRef<Matter.Render | null>(null);
  const [isRunning, setIsRunning] = useState(true);
  const [gravity, setGravity] = useState(1);
  const [restitution, setRestitution] = useState(0.9);
  const [friction, setFriction] = useState(0.1);
  const [showSettings, setShowSettings] = useState(false);
  const [selectedShape, setSelectedShape] = useState('circle');
  const [selectedDemo, setSelectedDemo] = useState('freefall');

  useEffect(() => {
    // Initialize Matter.js
    const Engine = Matter.Engine;
    const Render = Matter.Render;
    const World = Matter.World;
    const Bodies = Matter.Bodies;
    const Body = Matter.Body;
    const Composite = Matter.Composite;

    // Create engine
    const engine = Engine.create({
      gravity: { x: 0, y: gravity }
    });
    engineRef.current = engine;

    // Create renderer
    const render = Render.create({
      element: sceneRef.current!,
      engine: engine,
      options: {
        width: sceneRef.current!.clientWidth,
        height: 500,
        wireframes: false,
        background: '#f9fafb',
      }
    });
    renderRef.current = render;

    // Create walls
    const wallOptions = { 
      isStatic: true,
      render: { fillStyle: '#e5e7eb' }
    };
    
    const ground = Bodies.rectangle(
      render.options.width / 2, 
      render.options.height, 
      render.options.width, 
      50, 
      wallOptions
    );
    
    const leftWall = Bodies.rectangle(
      0, 
      render.options.height / 2, 
      50, 
      render.options.height, 
      wallOptions
    );
    
    const rightWall = Bodies.rectangle(
      render.options.width, 
      render.options.height / 2, 
      50, 
      render.options.height, 
      wallOptions
    );
    
    const ceiling = Bodies.rectangle(
      render.options.width / 2, 
      0, 
      render.options.width, 
      50, 
      wallOptions
    );

    // Add all bodies to the world
    World.add(engine.world, [ground, leftWall, rightWall, ceiling]);

    // Add initial objects based on selected demo
    setupDemo(selectedDemo, engine, render, Bodies, World, Body);

    // Run the engine
    Engine.run(engine);
    Render.run(render);

    // Handle window resize
    const handleResize = () => {
      if (sceneRef.current && renderRef.current) {
        renderRef.current.options.width = sceneRef.current.clientWidth;
        renderRef.current.canvas.width = sceneRef.current.clientWidth;
        Matter.Render.setPixelRatio(renderRef.current, window.devicePixelRatio);
      }
    };

    window.addEventListener('resize', handleResize);

    // Cleanup
    return () => {
      window.removeEventListener('resize', handleResize);
      Render.stop(render);
      World.clear(engine.world, false);
      Engine.clear(engine);
      render.canvas.remove();
      if (render.canvas.parentElement) {
        render.canvas.parentElement.removeChild(render.canvas);
      }
    };
  }, []);

  // Update physics properties when they change
  useEffect(() => {
    if (engineRef.current) {
      engineRef.current.gravity.y = gravity;
      
      // Update properties of all bodies
      const bodies = Matter.Composite.allBodies(engineRef.current.world);
      bodies.forEach(body => {
        if (!body.isStatic) {
          Matter.Body.set(body, 'restitution', restitution);
          Matter.Body.set(body, 'friction', friction);
        }
      });
    }
  }, [gravity, restitution, friction]);

  // Toggle simulation
  useEffect(() => {
    if (engineRef.current) {
      if (isRunning) {
        Matter.Runner.run(engineRef.current);
      } else {
        Matter.Runner.stop(engineRef.current);
      }
    }
  }, [isRunning]);

  // Change demo setup
  useEffect(() => {
    if (engineRef.current && renderRef.current) {
      resetSimulation();
      setupDemo(selectedDemo, engineRef.current, renderRef.current, Matter.Bodies, Matter.World, Matter.Body);
    }
  }, [selectedDemo]);

  const setupDemo = (
    demo: string, 
    engine: Matter.Engine, 
    render: Matter.Render, 
    Bodies: typeof Matter.Bodies, 
    World: typeof Matter.World,
    Body: typeof Matter.Body
  ) => {
    const width = render.options.width;
    const height = render.options.height;
    
    // Clear any existing bodies except walls
    const bodies = Matter.Composite.allBodies(engine.world);
    const walls = bodies.filter(body => body.isStatic);
    Matter.World.clear(engine.world, false);
    Matter.World.add(engine.world, walls);
    
    switch (demo) {
      case 'freefall':
        // Add a ball for free fall
        const ball = Bodies.circle(width / 2, 50, 30, {
          restitution: restitution,
          friction: friction,
          render: { fillStyle: '#6366f1' }
        });
        World.add(engine.world, ball);
        break;
        
      case 'projectile':
        // Add a ball with initial velocity for projectile motion
        const projectile = Bodies.circle(50, height - 100, 20, {
          restitution: restitution,
          friction: friction,
          render: { fillStyle: '#8b5cf6' }
        });
        Body.setVelocity(projectile, { x: 8, y: -10 });
        World.add(engine.world, projectile);
        break;
        
      case 'pendulum':
        // Create a pendulum
        const pendulumLength = 200;
        const pendulumAnchor = { x: width / 2, y: 100 };
        const pendulumBob = Bodies.circle(
          pendulumAnchor.x + pendulumLength, 
          pendulumAnchor.y, 
          30, 
          {
            restitution: restitution,
            friction: friction,
            render: { fillStyle: '#ec4899' }
          }
        );
        
        const constraint = Matter.Constraint.create({
          pointA: pendulumAnchor,
          bodyB: pendulumBob,
          length: pendulumLength,
          stiffness: 0.9,
          render: {
            strokeStyle: '#6b7280',
            lineWidth: 3
          }
        });
        
        World.add(engine.world, [pendulumBob, constraint]);
        break;
        
      case 'collision':
        // Add multiple objects for collision demo
        for (let i = 0; i < 10; i++) {
          const x = Math.random() * (width - 100) + 50;
          const y = Math.random() * (height / 2) + 50;
          const radius = Math.random() * 20 + 10;
          
          const shape = Math.random() > 0.5 
            ? Bodies.circle(x, y, radius, {
                restitution: restitution,
                friction: friction,
                render: { 
                  fillStyle: `hsl(${Math.random() * 360}, 70%, 70%)` 
                }
              })
            : Bodies.rectangle(x, y, radius * 2, radius * 2, {
                restitution: restitution,
                friction: friction,
                render: { 
                  fillStyle: `hsl(${Math.random() * 360}, 70%, 70%)` 
                }
              });
          
          World.add(engine.world, shape);
        }
        break;
    }
  };

  const resetSimulation = () => {
    if (engineRef.current && renderRef.current) {
      // Clear all bodies except walls
      const bodies = Matter.Composite.allBodies(engineRef.current.world);
      const walls = bodies.filter(body => body.isStatic);
      Matter.World.clear(engineRef.current.world, false);
      Matter.World.add(engineRef.current.world, walls);
      
      // Reset to running state
      setIsRunning(true);
    }
  };

  const addShape = () => {
    if (engineRef.current && renderRef.current && sceneRef.current) {
      const width = renderRef.current.options.width;
      const height = renderRef.current.options.height;
      
      let body;
      const commonOptions = {
        restitution: restitution,
        friction: friction,
        render: { fillStyle: '#6366f1' }
      };
      
      // Create shape based on selection
      switch (selectedShape) {
        case 'circle':
          body = Matter.Bodies.circle(
            width / 2,
            height / 4,
            30,
            commonOptions
          );
          break;
        case 'square':
          body = Matter.Bodies.rectangle(
            width / 2,
            height / 4,
            60,
            60,
            commonOptions
          );
          break;
        case 'rectangle':
          body = Matter.Bodies.rectangle(
            width / 2,
            height / 4,
            80,
            40,
            commonOptions
          );
          break;
        case 'polygon':
          body = Matter.Bodies.polygon(
            width / 2,
            height / 4,
            6,
            30,
            commonOptions
          );
          break;
      }
      
      Matter.World.add(engineRef.current.world, body);
    }
  };

  return (
    <div className="bg-white rounded-xl shadow-sm overflow-hidden">
      <div className="p-4 border-b border-gray-200">
        <h2 className="text-xl font-semibold text-gray-800">Physics Simulator</h2>
        <p className="text-gray-600 text-sm mt-1">
          Experiment with physics concepts in this interactive simulator
        </p>
      </div>
      
      <div className="p-4">
        <div className="mb-4 flex flex-wrap gap-2">
          <select
            value={selectedDemo}
            onChange={(e) => setSelectedDemo(e.target.value)}
            className="px-3 py-2 bg-white border border-gray-300 rounded-md text-sm shadow-sm focus:outline-none focus:ring-1 focus:ring-indigo-500"
          >
            <option value="freefall">Free Fall</option>
            <option value="projectile">Projectile Motion</option>
            <option value="pendulum">Pendulum</option>
            <option value="collision">Collision Physics</option>
          </select>
          
          <div className="flex gap-2">
            <button
              onClick={() => setIsRunning(!isRunning)}
              className="inline-flex items-center px-3 py-2 border border-gray-300 shadow-sm text-sm leading-4 font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
            >
              {isRunning ? <Pause className="h-4 w-4 mr-1" /> : <Play className="h-4 w-4 mr-1" />}
              {isRunning ? 'Pause' : 'Play'}
            </button>
            
            <button
              onClick={resetSimulation}
              className="inline-flex items-center px-3 py-2 border border-gray-300 shadow-sm text-sm leading-4 font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
            >
              <RotateCcw className="h-4 w-4 mr-1" />
              Reset
            </button>
            
            <button
              onClick={() => setShowSettings(!showSettings)}
              className="inline-flex items-center px-3 py-2 border border-gray-300 shadow-sm text-sm leading-4 font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
            >
              <Settings className="h-4 w-4 mr-1" />
              Settings
            </button>
          </div>
        </div>
        
        {showSettings && (
          <div className="mb-4 p-4 bg-gray-50 rounded-lg">
            <h3 className="text-md font-medium mb-3">Physics Properties</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Gravity: {gravity.toFixed(1)}
                </label>
                <input
                  type="range"
                  min="0"
                  max="2"
                  step="0.1"
                  value={gravity}
                  onChange={(e) => setGravity(parseFloat(e.target.value))}
                  className="w-full"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Bounciness: {restitution.toFixed(1)}
                </label>
                <input
                  type="range"
                  min="0"
                  max="1"
                  step="0.1"
                  value={restitution}
                  onChange={(e) => setRestitution(parseFloat(e.target.value))}
                  className="w-full"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Friction: {friction.toFixed(1)}
                </label>
                <input
                  type="range"
                  min="0"
                  max="1"
                  step="0.1"
                  value={friction}
                  onChange={(e) => setFriction(parseFloat(e.target.value))}
                  className="w-full"
                />
              </div>
            </div>
            
            <div className="mt-4 flex items-end gap-2">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Add Shape
                </label>
                <select
                  value={selectedShape}
                  onChange={(e) => setSelectedShape(e.target.value)}
                  className="px-3 py-2 bg-white border border-gray-300 rounded-md text-sm shadow-sm focus:outline-none focus:ring-1 focus:ring-indigo-500"
                >
                  <option value="circle">Circle</option>
                  <option value="square">Square</option>
                  <option value="rectangle">Rectangle</option>
                  <option value="polygon">Polygon</option>
                </select>
              </div>
              
              <button
                onClick={addShape}
                className="px-3 py-2 bg-indigo-600 text-white text-sm rounded-md hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
              >
                Add
              </button>
            </div>
          </div>
        )}
        
        <div 
          ref={sceneRef} 
          className="w-full h-[500px] border border-gray-200 rounded-lg overflow-hidden bg-gray-50"
        ></div>
        
        <div className="mt-4 text-sm text-gray-600">
          <p className="font-medium">How to use:</p>
          <ul className="list-disc pl-5 mt-1">
            <li>Select a physics demo from the dropdown menu</li>
            <li>Use the play/pause button to control the simulation</li>
            <li>Adjust gravity, bounciness, and friction in the settings</li>
            <li>Add different shapes to see how they interact</li>
            <li>Reset the simulation to start over</li>
          </ul>
        </div>
      </div>
    </div>
  );
};

export default PhysicsSimulator;